# DuckDuckGo AI Chat

Add-on for Firefox.
